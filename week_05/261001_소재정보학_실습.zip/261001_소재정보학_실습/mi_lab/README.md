# 소재정보학 최신 연구 동향 — 실습 (1시간)

UST 소재정보학 수업의 실습 자료입니다. 모든 코드는 **노트북 CPU에서 로컬로** 실행됩니다 (GPU, 인터넷 연결, API 키 불필요).

| 파일 | 내용 | 시간 |
|---|---|---|
| `00_환경확인.ipynb` | 설치가 제대로 되었는지 확인 | 수업 전 |
| `01_데이터분할과_외삽.ipynb` | 데이터 분할 방식에 따라 모델 성능이 얼마나 달라지는가 (Magpie + Random forest) | 약 25분 |
| `02_범용원자간포텐셜_CHGNet.ipynb` | 사전학습된 CHGNet으로 구조 최적화, 체적 탄성률, 산화수 추론, 분자동역학 | 약 25분 |
| `solutions/` | 정답 노트북 (실행 결과 포함) | 강사용 |

학생용 노트북에는 `# TODO`와 `...`로 표시된 빈칸이 있습니다. 빈칸을 채우기 전에 실행하면 오류가 나는 것이 정상입니다.

---

## 1. 설치 (수업 전에 미리 해 오세요)

**권장 환경**: Python 3.11 (3.13 이상은 chgnet 설치 불가), Windows 10/11, macOS, Linux 모두 가능. 설치 용량 약 1~3 GB (PyTorch 포함).

### 방법 A. Anaconda / Miniconda 사용 (권장)

Anaconda Prompt(Windows) 또는 터미널(macOS/Linux)에서 이 폴더로 이동한 뒤:

```bash
conda env create -f environment.yml
conda activate mi-lab
python -m ipykernel install --user --name mi-lab --display-name "Python (mi-lab)"
```

### 방법 B. Python venv 사용

Python 3.11이 설치되어 있다면:

```bash
python -m venv mi-lab
# Windows
mi-lab\Scripts\activate
# macOS / Linux
source mi-lab/bin/activate

pip install -r requirements.txt
python -m ipykernel install --user --name mi-lab --display-name "Python (mi-lab)"
```

> **Linux 사용자 참고**: Linux에서는 `pip install torch`가 GPU(CUDA) 라이브러리까지 받아서 수 GB가 됩니다.
> CPU만 쓸 경우 먼저 `pip install torch --index-url https://download.pytorch.org/whl/cpu`를 실행한 뒤 `pip install -r requirements.txt`를 실행하세요.
> Windows와 macOS는 기본 설치로 충분합니다.

### 설치 확인

```bash
python check_env.py
```

마지막 줄에 `모든 항목 OK - 실습 준비 완료`가 나오면 됩니다.
또는 Jupyter에서 `00_환경확인.ipynb`를 열어 모든 셀을 실행하세요.

## 2. 실행

```bash
conda activate mi-lab        # 또는 venv 활성화
jupyter lab
```

브라우저가 열리면 `01_...`, `02_...` 노트북을 순서대로 엽니다. 커널은 **Python (mi-lab)** 을 선택하세요.

---

## 3. 폴더 구조

```
mi_lab/
├── README.md
├── 강사용_가이드.md
├── environment.yml             # conda 환경
├── requirements.txt            # pip 패키지 (최소 버전)
├── requirements-tested.txt     # 실행을 확인한 정확한 버전
├── check_env.py                # 터미널용 설치 확인
├── 00_환경확인.ipynb
├── 01_데이터분할과_외삽.ipynb
├── 02_범용원자간포텐셜_CHGNet.ipynb
├── data/
│   ├── matbench_expt_gap.csv   # 실험 밴드갭 4,604개 (화학식, 밴드갭)
│   └── expt_gap_magpie.csv     # 미리 계산한 Magpie descriptor (시간 절약용)
└── solutions/
    ├── 01_데이터분할과_외삽_정답.ipynb
    └── 02_범용원자간포텐셜_CHGNet_정답.ipynb
```

## 4. 문제 해결

| 증상 | 해결 |
|---|---|
| `chgnet` 설치 실패 또는 컴파일 오류 | Python 버전을 확인하세요. chgnet 0.4.2는 **Python 3.10~3.12**용 설치 파일만 제공합니다. 3.13 이상이면 설치되지 않으므로 3.11 환경을 만드세요(방법 A 권장). |
| `import torch`에서 DLL 오류 (Windows) | [Microsoft Visual C++ 재배포 패키지](https://aka.ms/vs/17/release/vc_redist.x64.exe)를 설치한 뒤 다시 시도하세요. |
| 버전 충돌 오류 | `pip install -r requirements-tested.txt`로 검증된 버전을 설치하세요. |
| 실습 1의 descriptor 계산이 너무 오래 걸림 | 노트북의 `USE_CACHE = True`로 바꾸면 미리 계산한 파일을 씁니다. |
| 노트북에서 패키지를 못 찾음 | 커널이 `Python (mi-lab)`인지 확인하세요 (Jupyter 오른쪽 위). |
| 경고(Warning) 메시지가 많이 나옴 | 대부분 무시해도 됩니다. 오류(Error)만 확인하세요. |

## 5. 데이터 출처와 라이선스

- `matbench_expt_gap`: Matbench v0.1 (A. Dunn et al., *npj Comput. Mater.* 6, 138, 2020). 원 데이터: Y. Zhuo, A. Mansouri Tehrani, J. Brgoch, *J. Phys. Chem. Lett.* 9, 1668 (2018).
  이 파일은 CrabNet 저장소(MIT License, © 2021 Sterling G. Baird)에 포함된 사본을 사용했으며, `matminer.datasets.load_dataset("matbench_expt_gap")`로 받는 데이터와 같습니다(4,604개).
- CHGNet: B. Deng et al., *Nat. Mach. Intell.* 5, 1031 (2023). 사전학습 모델은 `chgnet` 패키지에 포함되어 있습니다(현재 기본 모델 v0.3.0, 파라미터 약 41만 개).
