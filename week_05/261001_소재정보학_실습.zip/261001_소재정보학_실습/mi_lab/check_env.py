"""터미널에서 실습 환경을 확인하는 스크립트: python check_env.py"""
import importlib, sys

print("Python", sys.version.split()[0])
ok = True
for p in ["numpy", "pandas", "matplotlib", "sklearn", "pymatgen.core", "matminer", "torch", "chgnet", "ase"]:
    try:
        m = importlib.import_module(p)
        print(f"  OK   {p:15s} {getattr(m, '__version__', '')}")
    except Exception as e:
        ok = False
        print(f"  FAIL {p:15s} {e}")

try:
    import warnings; warnings.filterwarnings("ignore")
    from chgnet.model import CHGNet
    from pymatgen.core import Structure, Lattice
    model = CHGNet.load()
    e = model.predict_structure(Structure(Lattice.cubic(4.2), ["Mg", "O"], [[0, 0, 0], [.5, .5, .5]]))["e"]
    print(f"  OK   CHGNet 예측 테스트 (MgO: {float(e):.3f} eV/atom)")
except Exception as e:
    ok = False
    print("  FAIL CHGNet 예측 테스트:", e)

print("\n모든 항목 OK - 실습 준비 완료" if ok else "\n실패 항목이 있습니다. README의 '문제 해결'을 확인하세요.")
